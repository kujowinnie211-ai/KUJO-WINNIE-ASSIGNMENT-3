clc;
clear;
close all;

% LEAF INFORMATION
% Leaf 1 - Lemon
leaf(1).plant = 'Lemon';
leaf(1).shape = 'Ovate';
leaf(1).margin = 'Serrated';
leaf(1).venation = 'Pinnate';
leaf(1).apex = 'Acute';
leaf(1).base = 'Cuneate';
leaf(1).arrangement = 'Alternate';
leaf(1).type = 'Simple';
leaf(1).texture = 'Smooth';

% Leaf 2 - Guava
leaf(2).plant = 'Guava';
leaf(2).shape = 'Elliptic';
leaf(2).margin = 'Entire';
leaf(2).venation = 'Pinnate';
leaf(2).apex = 'Acute';
leaf(2).base = 'Cuneate';
leaf(2).arrangement = 'Opposite';
leaf(2).type = 'Simple';
leaf(2).texture = 'Smooth';

% Leaf 3 - Mango
leaf(3).plant = 'Mango';
leaf(3).shape = 'Lanceolate';
leaf(3).margin = 'Entire';
leaf(3).venation = 'Pinnate';
leaf(3).apex = 'Acuminate';
leaf(3).base = 'Cuneate';
leaf(3).arrangement = 'Alternate';
leaf(3).type = 'Simple';
leaf(3).texture = 'Smooth';

% Leaf 4 - Maize
leaf(4).plant = 'Maize';
leaf(4).shape = 'Linear';
leaf(4).margin = 'Entire';
leaf(4).venation = 'Parallel';
leaf(4).apex = 'Acute';
leaf(4).base = 'Cuneate';
leaf(4).arrangement = 'Alternate';
leaf(4).type = 'Simple';
leaf(4).texture = 'Smooth';

% Leaf 5 - Cassava
leaf(5).plant = 'Cassava';
leaf(5).shape = 'Palmate-lobed';
leaf(5).margin = 'Lobed';
leaf(5).venation = 'Palmate';
leaf(5).apex = 'Acute';
leaf(5).base = 'Cordate';
leaf(5).arrangement = 'Alternate';
leaf(5).type = 'Simple';
leaf(5).texture = 'Smooth';

%% IMAGE FILE NAMES
imageNames = {
    'leaf1.jpeg'
    'leaf2.jpg'
    'leaf3.jpg'
    'leaf4.jpg'
    'leaf5.jpg'
};

% READ AND PROCESS IMAGES
for i = 1:5
    leaf(i).originalImage = imread(imageNames{i});
    leaf(i).grayImage = rgb2gray(leaf(i).originalImage);
    leaf(i).binaryImage = imbinarize(leaf(i).grayImage);
    leaf(i).edgeImage = edge(leaf(i).grayImage);

    % MEASURE THE LEAF
    cleanImage = bwareaopen(leaf(i).binaryImage,500);
    measurements = regionprops(cleanImage, ...
        'Area','Perimeter','MajorAxisLength','MinorAxisLength');
    if ~isempty(measurements)
        [~,n] = max([measurements.Area]);
        leaf(i).area = measurements(n).Area;
        leaf(i).perimeter = measurements(n).Perimeter;
        leaf(i).length = measurements(n).MajorAxisLength;
        leaf(i).width = measurements(n).MinorAxisLength;
    else
        leaf(i).area = 0;
        leaf(i).perimeter = 0;
        leaf(i).length = 0;
        leaf(i).width = 0;
    end
end

% DISPLAY LEAF INFORMATION
for i = 1:5
    fprintf('\n\nLeaf %d: %s\n\n',i,leaf(i).plant);
    fprintf('Shape: %s\n',leaf(i).shape);
    fprintf('Margin: %s\n',leaf(i).margin);
    fprintf('Venation: %s\n',leaf(i).venation);
    fprintf('Apex: %s\n',leaf(i).apex);
    fprintf('Base: %s\n',leaf(i).base);
    fprintf('Arrangement: %s\n',leaf(i).arrangement);
    fprintf('Type: %s\n',leaf(i).type);
    fprintf('Texture: %s\n',leaf(i).texture);
   
    fprintf('\nMeasurements:\n\n');
    fprintf('Area: %.2f pixels\n',leaf(i).area);
    fprintf('Perimeter: %.2f pixels\n',leaf(i).perimeter);
    fprintf('Length: %.2f pixels\n',leaf(i).length);
    fprintf('Width: %.2f pixels\n',leaf(i).width);
end

% DISPLAY IMAGES
for i = 1:5
    figure;
    subplot(2,2,1);
    imshow(leaf(i).originalImage);
    title(['Original - ' leaf(i).plant]);

    subplot(2,2,2);
    imshow(leaf(i).grayImage);
    title('Grayscale');

    subplot(2,2,3);
    imshow(leaf(i).binaryImage);
    title('Binary');

    subplot(2,2,4);
    imshow(leaf(i).edgeImage);
    title('Edge');
end