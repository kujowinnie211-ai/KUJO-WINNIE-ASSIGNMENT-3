clc;
clear;
close all;

% IMPORT STUDENT INFORMATION FROM EXCEL
inputFile = 'student_details.xlsx';
students = readtable(inputFile, ...
    'VariableNamingRule', 'preserve');

% CREATE A FOLDER FOR THE PLOTS
plotFolder = 'Assignment_Plots';
if ~exist(plotFolder, 'dir')
    mkdir(plotFolder);
end

% GENDER BAR GRAPH
genderCounts = groupcounts(students, 'GENDER');
figure;
bar(categorical(genderCounts.GENDER), ...
    genderCounts.GroupCount);
title('Number of Students by Gender');
xlabel('Gender');
ylabel('Number of Students');
grid on;
saveas(gcf, fullfile(plotFolder, 'gender_bar_graph.png'));

% AGE LINE GRAPH
figure;
plot(students.AGE,'-o');
title('Age of Students');
xlabel('Student Number');
ylabel('Age');
grid on;
saveas(gcf,fullfile(plotFolder,'Age_Line_Graph.png'));
close;

% AGE HISTOGRAM
figure;
histogram(students.AGE);
title('Age Distribution of Students');
xlabel('Age');
ylabel('Number of Students');
grid on;
saveas(gcf, fullfile(plotFolder, 'Age_graph.png'));

% RELIGION PIE CHART
figure;
pie(categorical(students.RELIGION));
title('Religion of Students');
saveas(gcf, fullfile(plotFolder,'Religion_Pie_Chart.png'));
close;

% ASSOCIATION GRAPH
associationCounts = groupcounts(students, 'ASSOCIATION');
figure;
bar(categorical(associationCounts.ASSOCIATION), ...
    associationCounts.GroupCount);
title('Number of Students by Association');
xlabel('Association');
ylabel('Number of Students');
grid on;
saveas(gcf, fullfile(plotFolder, 'Association_graph.png'));

% HOMETOWN GRAPH
hometownCounts = groupcounts(students, 'HOMETOWN');
figure;
bar(categorical(hometownCounts.HOMETOWN), ...
    hometownCounts.GroupCount);
title('Number of Students by Hometown');
xlabel('Hometown');
ylabel('Number of Students');
grid on;
saveas(gcf, fullfile(plotFolder, 'Hometown_graph.png'));